function(f) {
    a.evalOSD1234 = "" + f;
}