function() {
    return /^\d+$/.test(this.toString());
}