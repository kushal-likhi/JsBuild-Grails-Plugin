function(str) {
    return this.indexOf(str) === 0;
}