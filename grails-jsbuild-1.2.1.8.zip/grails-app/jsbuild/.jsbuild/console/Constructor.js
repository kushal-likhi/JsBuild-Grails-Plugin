function() {
    jsbuildRuntimeBasePackage.console.ui.buildUI();
    jsbuildRuntimeBasePackage.console.expanded = true;
    jsbuildRuntimeBasePackage.console.currentIndex = jsbuildRuntimeBasePackage.console.stack.length
}