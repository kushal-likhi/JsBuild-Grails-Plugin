function() {
    return (this.toString().trim().length == 0)
}