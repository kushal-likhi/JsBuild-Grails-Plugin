function() {
    return this.toString().length
}