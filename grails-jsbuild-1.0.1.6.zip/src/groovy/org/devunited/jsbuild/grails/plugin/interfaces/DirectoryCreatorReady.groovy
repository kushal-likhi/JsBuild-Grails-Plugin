package org.devunited.jsbuild.grails.plugin.interfaces

/**
 * Created by IntelliJ IDEA.
 * User: kushal
 * Date: 8/15/11
 * Time: 4:52 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DirectoryCreatorReady {

    public File createDirIfNotExist()

}