package org.devunited.jsbuild.component

/**
 * Created by IntelliJ IDEA.
 * User: kushal
 * Date: 8/21/11
 * Time: 10:50 PM
 * To change this template use File | Settings | File Templates.
 */
class ComponentRegistryData {
    String name
    String basePackage
    String exportName
    Integer priority
}
