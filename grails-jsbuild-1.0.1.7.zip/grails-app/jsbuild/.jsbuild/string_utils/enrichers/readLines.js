function() {
    return this.toString().split('\n');
}