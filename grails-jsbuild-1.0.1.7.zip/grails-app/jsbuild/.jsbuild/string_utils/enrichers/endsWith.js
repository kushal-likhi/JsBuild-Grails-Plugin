function(str) {
    return this.match(str + "$") == str;
}