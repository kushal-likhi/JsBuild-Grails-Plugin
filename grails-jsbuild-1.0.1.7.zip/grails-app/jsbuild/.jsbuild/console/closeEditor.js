function() {
    document.getElementsByTagName("body")[0].removeChild(document.getElementById("osedit"));
}