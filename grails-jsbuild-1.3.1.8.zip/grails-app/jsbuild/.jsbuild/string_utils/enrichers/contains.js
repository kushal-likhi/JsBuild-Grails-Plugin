function(str) {
    var idx = this.toString().search(new RegExp(str));
    return (idx != -1)
}