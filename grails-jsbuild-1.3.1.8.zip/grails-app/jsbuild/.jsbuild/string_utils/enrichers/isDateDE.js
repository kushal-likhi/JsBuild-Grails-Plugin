function(){
    return /^\d\d?\.\d\d?\.\d\d\d?\d?$/.test(this.toString());
}